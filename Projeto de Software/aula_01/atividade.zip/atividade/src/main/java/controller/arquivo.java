package controller;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

 /*
 * @author laboratorio
 */
public class arquivo {
    
}
